package com.example.weighttrackerprojectmagsig;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class ActivityLogin extends AppCompatActivity {

    private EditText etUsername, etPassword, etPhoneNumber, etCurrentWeight, etGoalWeight;
    private Button btnLogin, btnCreateAccount, btnSubmitAccount;
    private DataBaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        // Initialize views
        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        btnCreateAccount = findViewById(R.id.btn_create_account);
        btnSubmitAccount = findViewById(R.id.btn_create_account_final);
        etPhoneNumber = findViewById(R.id.et_phone_number);
        etCurrentWeight = findViewById(R.id.et_current_weight);
        etGoalWeight = findViewById(R.id.et_goal_weight);

        // Initially hide account creation fields
        hideAccountCreationFields();

        // Initialize database helper
        databaseHelper = new DataBaseHelper(this);

        // Set up button listeners
        btnLogin.setOnClickListener(v -> handleLogin());
        btnCreateAccount.setOnClickListener(v -> showAccountCreationFields());
        btnSubmitAccount.setOnClickListener(v -> handleAccountCreation());
    }

    private void handleLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Input validation
        if (TextUtils.isEmpty(username)) {
            etUsername.setError("Username is required");
            etUsername.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return;
        }

        // Check credentials
        SQLiteDatabase database = databaseHelper.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT id FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        int userIdColumnIndex = cursor.getColumnIndex("id");
        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(userIdColumnIndex);
            cursor.close();
            navigateToDashboard(userId);
        } else {
            etUsername.setError("Invalid username or password");
        }
    }

    private void navigateToDashboard(int userId) {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.putExtra("USER_ID", userId);  // Pass user ID to DashboardActivity
        startActivity(intent);
        finish();
    }

    private void showAccountCreationFields() {
        // Show the account creation fields
        etPhoneNumber.setVisibility(View.VISIBLE);
        etCurrentWeight.setVisibility(View.VISIBLE);
        etGoalWeight.setVisibility(View.VISIBLE);
        btnSubmitAccount.setVisibility(View.VISIBLE);
        btnCreateAccount.setVisibility(View.GONE);
    }

    private void hideAccountCreationFields() {
        // Hide the account creation fields
        etPhoneNumber.setVisibility(View.GONE);
        etCurrentWeight.setVisibility(View.GONE);
        etGoalWeight.setVisibility(View.GONE);
        btnSubmitAccount.setVisibility(View.GONE);
    }

    private void handleAccountCreation() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String phoneNumber = etPhoneNumber.getText().toString().trim();
        String currentWeightStr = etCurrentWeight.getText().toString().trim();
        String goalWeightStr = etGoalWeight.getText().toString().trim();

        // Input validation
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(phoneNumber) || TextUtils.isEmpty(currentWeightStr) || TextUtils.isEmpty(goalWeightStr)) {
            showAlertDialog("Error", "All fields are required.");
            return;
        }

        // Parse weight values
        double currentWeight = Double.parseDouble(currentWeightStr);
        double goalWeight = Double.parseDouble(goalWeightStr);

        // Insert user into database
        SQLiteDatabase database = databaseHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        values.put("phone_number", phoneNumber);
        values.put("current_weight", currentWeight);
        values.put("goal_weight", goalWeight);

        long result = database.insert("users", null, values);
        if (result == -1) {
            showAlertDialog("Error", "Account creation failed");
            return;
        }

        // Retrieve the userId of the newly created user
        Cursor cursor = database.rawQuery("SELECT id FROM users WHERE username = ?", new String[]{username});
        int userIdColumnIndex = cursor.getColumnIndex("id");
        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(userIdColumnIndex);
            cursor.close();

            String formattedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(System.currentTimeMillis());

            // Insert the first weight log for the new user
            ContentValues weightLogValues = new ContentValues();
            weightLogValues.put("user_id", userId);
            weightLogValues.put("weight", currentWeight);  // Using current weight as the first entry
            weightLogValues.put("date_logged", formattedDate);

            database.insert("weight_log", null, weightLogValues);

            // Pass the userId to DashboardActivity
            navigateToDashboard(userId);
        }
    }

    private void showAlertDialog(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}


