package com.example.weighttrackerprojectmagsig;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    private TextView welcomeTextView;
    private TextView currentWeightTextView;
    private TextView goalWeightTextView;

    private EditText etAddWeight;
    private GridLayout gridLayout;
    private Button addWeightButton;
    private Button settingsButton;
    private DataBaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        gridLayout = findViewById(R.id.gridlayout);
        addWeightButton = findViewById(R.id.addWeightButton);
        settingsButton = findViewById(R.id.settingsButton);
        welcomeTextView = findViewById(R.id.welcomeTextView);
        currentWeightTextView = findViewById(R.id.currentWeightTextView);
        goalWeightTextView = findViewById(R.id.goalWeightTextView);
        etAddWeight = findViewById(R.id.et_add_weight);

        // Initialize database helper
        databaseHelper = new DataBaseHelper(this);

        // Get user ID from the Intent
        int userId = getIntent().getIntExtra("USER_ID", -1);

        if (userId == -1) {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
            return;
        }

        // Retrieve user data from the database
        Cursor cursor = databaseHelper.getUserDetails(userId);

        int usernameColumnIndex = cursor.getColumnIndex("username");
        int currentWeightColumnIndex = cursor.getColumnIndex("current_weight");
        int goalWeightColumnIndex = cursor.getColumnIndex("goal_weight");

        if (cursor != null && cursor.moveToFirst()) {
            // Extract user details
            String username = cursor.getString(usernameColumnIndex);
            double currentWeight = cursor.getDouble(currentWeightColumnIndex);
            double goalWeight = cursor.getDouble(goalWeightColumnIndex);

            // Dynamically set the text of the TextViews
            welcomeTextView.setText("Welcome, " + username);
            currentWeightTextView.setText("Current Weight: " + currentWeight + " lbs");
            goalWeightTextView.setText("Goal Weight: " + goalWeight + " lbs");

            cursor.close();  // Close the cursor after use
        } else {
            Toast.makeText(this, "No user data found", Toast.LENGTH_SHORT).show();
        }

        // Load weight logs into the grid layout
        loadWeightLogs(userId);

        // Add button listener for adding weight log
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewWeightLog(userId);  // Pass userId when adding a weight log
            }
        });

        // Add button listener for settings
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pass userId to SettingsActivity
                Intent intent = new Intent(DashboardActivity.this, SettingsActivity.class);
                intent.putExtra("USER_ID", userId);
                startActivity(intent);
            }
        });
    }

    private void loadWeightLogs(int userId) {
        // Query the database for weight logs for the current user
        Cursor cursor = databaseHelper.getWeightLogs(userId);

        if (cursor != null && cursor.moveToFirst()) {
            // Clear existing data in the GridLayout
            gridLayout.removeAllViews();

            // Add column headers to the grid
            addGridHeader();

            // Get the column indices for date_logged and weight
            int dateLoggedIndex = cursor.getColumnIndex("date_logged");
            int weightIndex = cursor.getColumnIndex("weight");

            // Loop through the cursor and create rows dynamically
            do {
                String dateLogged = cursor.getString(dateLoggedIndex);
                float weight = cursor.getFloat(weightIndex);

                // Create a row for each weight log entry
                addWeightLogRow(dateLogged, weight);

            } while (cursor.moveToNext());

            cursor.close();  // Close the cursor after use
        } else {
            Toast.makeText(this, "No weight logs found", Toast.LENGTH_SHORT).show();
        }
    }

    private void addGridHeader() {
        // Add the column headers to the grid layout
        TextView dateHeader = new TextView(this);
        dateHeader.setText("Date");
        dateHeader.setGravity(View.TEXT_ALIGNMENT_CENTER);
        gridLayout.addView(dateHeader);

        TextView weightHeader = new TextView(this);
        weightHeader.setText("Weight (lbs)");
        weightHeader.setGravity(View.TEXT_ALIGNMENT_CENTER);
        gridLayout.addView(weightHeader);

        TextView actionHeader = new TextView(this);
        actionHeader.setText("Action");
        actionHeader.setGravity(View.TEXT_ALIGNMENT_CENTER);
        gridLayout.addView(actionHeader);
    }

    private void addWeightLogRow(String dateLogged, float weight) {
        // Create a row dynamically for each weight log
        TextView dateTextView = new TextView(this);
        dateTextView.setText(dateLogged);
        dateTextView.setGravity(View.TEXT_ALIGNMENT_CENTER);
        gridLayout.addView(dateTextView);

        TextView weightTextView = new TextView(this);
        weightTextView.setText(String.valueOf(weight));
        weightTextView.setGravity(View.TEXT_ALIGNMENT_CENTER);
        gridLayout.addView(weightTextView);

        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle weight log deletion
                deleteWeightLog(dateLogged);
            }
        });
        gridLayout.addView(deleteButton);
    }

    private void deleteWeightLog(String dateLogged) {
        // Delete the weight log from the database
        databaseHelper.deleteWeightLog(dateLogged);
        loadWeightLogs(getIntent().getIntExtra("USER_ID", -1));  // Reload the weight logs after deletion
        Toast.makeText(this, "Weight log deleted", Toast.LENGTH_SHORT).show();
    }

    private void addNewWeightLog(int userId) {

        // Get the entered weight from EditText
        String weightInput = etAddWeight.getText().toString();

        // Validate input
        if (weightInput.isEmpty()) {
            Toast.makeText(this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            float newWeight = Float.parseFloat(weightInput);
            if (newWeight <= 0) {
                Toast.makeText(this, "Weight must be greater than 0", Toast.LENGTH_SHORT).show();
                return;
            }

            String dateLogged = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            // Insert new weight log into the database

            databaseHelper.insertWeightLog(userId, newWeight, dateLogged);

            // Clear the input field
            etAddWeight.setText("");

            loadWeightLogs(userId);  // Reload the weight logs to reflect the new entry
            Toast.makeText(this, "Weight log added successfully", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
        }
    }
}

