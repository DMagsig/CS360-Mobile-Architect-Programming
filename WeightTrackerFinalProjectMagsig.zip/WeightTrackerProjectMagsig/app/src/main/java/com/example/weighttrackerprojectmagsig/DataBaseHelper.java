package com.example.weighttrackerprojectmagsig;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "DailyWeightTracker.db";
    private static final int DATABASE_VERSION = 2;

    // Table names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHT_LOG = "weight_log";

    // Users table columns
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_PHONE_NUMBER = "phone_number";
    private static final String COLUMN_CURRENT_WEIGHT = "current_weight";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_SMS_NOTIFICATION_ENABLED = "sms_notification_enabled";

    // Weight log table columns
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_DATE_LOGGED = "date_logged";
    private static final String COLUMN_USER_ID = "user_id";

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " +
                COLUMN_PASSWORD + " TEXT NOT NULL, " +
                COLUMN_PHONE_NUMBER + " TEXT, " +
                COLUMN_CURRENT_WEIGHT + " REAL, " +
                COLUMN_GOAL_WEIGHT + " REAL, " +
                COLUMN_SMS_NOTIFICATION_ENABLED + " INTEGER DEFAULT 0);";

        String createWeightLogTable = "CREATE TABLE IF NOT EXISTS " + TABLE_WEIGHT_LOG + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_ID + " INTEGER NOT NULL, " +
                COLUMN_WEIGHT + " REAL NOT NULL, " +
                COLUMN_DATE_LOGGED + " TEXT NOT NULL, " +
                "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + "));";

        db.execSQL(createUsersTable);
        db.execSQL(createWeightLogTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // Add sms_notification_enabled column for older versions
            db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COLUMN_SMS_NOTIFICATION_ENABLED + " INTEGER DEFAULT 0;");
        }
    }

    // General method to retrieve a single column value
    private Cursor getColumnValue(String table, String column, String whereClause, String[] whereArgs) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(table, new String[]{column}, whereClause, whereArgs, null, null, null);
    }

    // Get SMS notification status for a user
    public boolean getSMSNotificationStatus(int userId) {
        Cursor cursor = getColumnValue(TABLE_USERS, COLUMN_SMS_NOTIFICATION_ENABLED, COLUMN_ID + " = ?", new String[]{String.valueOf(userId)});
        boolean isEnabled = false;
        if (cursor.moveToFirst()) {
            isEnabled = cursor.getInt(0) == 1; // 1 = enabled, 0 = disabled
        }
        cursor.close();
        return isEnabled;
    }

    // Update SMS notification status for a user
    public void updateSMSNotification(int userId, boolean isEnabled) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SMS_NOTIFICATION_ENABLED, isEnabled ? 1 : 0);
        db.update(TABLE_USERS, values, COLUMN_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    // Retrieve user details
    public Cursor getUserDetails(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT " + COLUMN_USERNAME + ", " + COLUMN_CURRENT_WEIGHT + ", " + COLUMN_GOAL_WEIGHT + ", " + COLUMN_SMS_NOTIFICATION_ENABLED +
                        " FROM " + TABLE_USERS + " WHERE " + COLUMN_ID + " = ?",
                new String[]{String.valueOf(userId)}
        );
    }

    // Insert a new weight log
    public void insertWeightLog(int userId, float weight, String dateLogged) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_WEIGHT, weight);
        values.put(COLUMN_DATE_LOGGED, dateLogged);
        db.insert(TABLE_WEIGHT_LOG, null, values);
    }

    // Get weight logs for a user
    public Cursor getWeightLogs(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT " + COLUMN_DATE_LOGGED + ", " + COLUMN_WEIGHT +
                        " FROM " + TABLE_WEIGHT_LOG + " WHERE " + COLUMN_USER_ID + " = ? ORDER BY " + COLUMN_DATE_LOGGED + " DESC",
                new String[]{String.valueOf(userId)}
        );
    }
    // Method to delete a weight log based on the date_logged
    public void deleteWeightLog(String dateLogged) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Define the condition for the deletion (based on the date_logged)
        String whereClause = COLUMN_DATE_LOGGED + " = ?";
        String[] whereArgs = new String[]{dateLogged};

        // Perform the deletion in the "weight_log" table
        db.delete(TABLE_WEIGHT_LOG, whereClause, whereArgs);

    }
}
