package com.example.weighttrackerprojectmagsig;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private DataBaseHelper dbHelper;
    private Switch smsSwitch;
    private Button saveButton, homeButton, logoutButton;
    private int userId; // The ID of the currently logged-in user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize the database helper and views
        dbHelper = new DataBaseHelper(this);
        smsSwitch = findViewById(R.id.switchSMSNotif);
        saveButton = findViewById(R.id.saveButton);
        homeButton = findViewById(R.id.homeButton);
        logoutButton = findViewById(R.id.logoutButton);

        // Get the userId passed from DashboardActivity
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            finish(); // Exit activity if user ID is invalid
            return;
        }

        // Load the current SMS notification preference
        loadSettings();

        // Save settings when the save button is clicked
        saveButton.setOnClickListener(v -> saveSettings());

        // Navigate back to DashboardActivity
        homeButton.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, DashboardActivity.class);
            intent.putExtra("USER_ID", userId); // Pass user ID back to DashboardActivity
            startActivity(intent);
            finish();
        });

        // Log the user out and navigate to the login activity
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, ActivityLogin.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }

    // Load the SMS notification status for the user
    private void loadSettings() {
        boolean isSMSNotifEnabled = dbHelper.getSMSNotificationStatus(userId);
        smsSwitch.setChecked(isSMSNotifEnabled);
    }

    // Save the SMS notification status
    private void saveSettings() {
        boolean isSwitchChecked = smsSwitch.isChecked();
        dbHelper.updateSMSNotification(userId, isSwitchChecked);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) {
            dbHelper.close(); // Ensure the database connection is closed when activity is destroyed
        }
    }
}
